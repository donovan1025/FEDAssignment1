# FEDAssignment1
This is my FED Assignment project.
Project Theme : Coldplay Band Website
The website is dedicated to fans who want to buy merch, buy upcoming concert tickets and see old photos and albums of the band
What I'm going to create:

DESKTOP:
1. Main Page consisting of Menu Bar above, main page showing latest albums, tours, merchandise etc. With links to them
2. Catalogue to show past photos, memories of tours and old albums(albums purchasable and links to shop)
3. Merchandise shop to buy clothes and albums
4. Tour section showing upcoming tours and button to purchase tickets
5. Social media links from menu

MOBILE:
1. Main Page consisting of Menu button which shows the menu, main page showing latest albums, tours, merchandise etc. With links to them
2. Catalogue to show past photos, memories of tours and old albums(albums purchasable and links to shop)
3. Merchandise shop to buy clothes and albums
4. Tour section showing upcoming tours and button to purchase tickets
5. Social media links from menu
